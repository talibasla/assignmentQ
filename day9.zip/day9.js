const fs = require('fs');
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.question('Enter a number: ', (num) => {
    const table = generateTable(num);
    fs.writeFile(`Table${num}.txt`, table, (err) => {
        if (err) throw err;
        console.log(`The multiplication table for ${num} has been saved to a file.`);
        readline.close();
    });
});

function generateTable(num) {
    let table = '';
    for (let i = 1; i <= 10; i++) {
        const result = i * num;
        table += `${num} x ${i} = ${result}\n`;
    }
    return table;
}